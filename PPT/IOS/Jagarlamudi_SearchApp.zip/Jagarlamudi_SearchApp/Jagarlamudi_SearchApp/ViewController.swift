//
//  ViewController.swift
//  Jagarlamudi_SearchApp
//
//  Created by student on 10/7/21.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
      @IBOutlet weak var topicInfoText: UITextView!
    
      @IBOutlet weak var searchTextField: UITextField!

      @IBOutlet weak var moreImages: UIButton!
      
      @IBOutlet weak var searchBtn: UIButton!
          
      @IBOutlet weak var resetButton: UIButton!
      
      var array=[["animal1","animal2","animal3","animal4","animal5"],["bird1","bird2","bird3","bird4","bird5"],
                 ["chocolate1","chocolate2","chocolate3","chocolate4","chocolate5"],["flag1","flag2","flag3","flag4","flag5"],
                 ["flower1","flower2","flower3","flower4","flower5"],["searchnotfound"]]
      
      var animal_keywords=["pet","creature","wildlife","wildbeast","orgnisms"]
      
      var bird_keywords=["chick","warbler","fowl","raptor","fledgling"]
      
      var chocolate_keywords=["dairymilk","ferrerorocher","milkybar","twix","bounty"]
      
      var flag_keywords=["india","srilanka","america","pakistan","flag"]
      
      var flower_keywords=["blossom", "floret","bloom","flower","sunflower"]
      
      var topic=0
      var animal:Int!
      var bird:Int!
      var chocolate:Int!
      var flag:Int!
      var flower:Int!
      
      
      override func viewDidLoad() {
          super.viewDidLoad()
          // Do any additional setup after loading the view.
          // topicInfoText.text="Hai"
          // moreImages.isEnabled=false
          moreImages.isHidden=true
          topicInfoText.isHidden=true
          searchBtn.isEnabled=false
          resetButton.alpha=0.5
          resetButton.isHidden=true
          resultImage.image=UIImage(named: array[5][0])
      }
      
      //if the entered key word does not match with any of the key words from the 5 arrays display the blank image
      
      @IBAction func searchButtonAction(_ sender: UIButton) {
          animal=0
          bird=0
          chocolate=0
          flag=0
          flower=0
          moreImages.isHidden=false
        
          topicInfoText.isHidden=false
          resetButton.isHidden=false
         
          if(animal_keywords.contains(searchTextField.text!)){
              moreImages.isEnabled=true
              
              resultImage.image=UIImage(named: array[0][animal])
              topic=1
              topicInfoText.text="Animals  are multicellular, eukaryotic organisms in the biological kingdom Animalia. With few exceptions, animals consume organic material, breathe oxygen, are able to move, can reproduce sexually, and go through an ontogenetic stage in which their body consists of a hollow sphere of cells, the blastula, during embryonic development."
              
          }
          else if(bird_keywords.contains(searchTextField.text!)){
              moreImages.isEnabled=true
              resultImage.image=UIImage(named: array[1][0])
              topic=2
              topicInfoText.text="Birds are a group of warm-blooded vertebrates constituting the class characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a strong yet lightweight skeleton"
          }
          else if(chocolate_keywords.contains(searchTextField.text!)){
              moreImages.isEnabled=true
              resultImage.image=UIImage(named: array[2][bird])
              topic=3
              topicInfoText.text="Chocolate is a food product made from roasted and ground cacao pods, that is available as a liquid, solid or paste, on its own or as a flavoring agent in other foods"
              
          }
          else if(flag_keywords.contains(searchTextField.text!)){
              moreImages.isEnabled=true
              resultImage.image=UIImage(named: array[3][chocolate])
              topic=4
              topicInfoText.text="A flag is a piece of fabric with a distinctive design and colours. It is used as a symbol, a signalling device, or for decoration."
          }
          else if(flower_keywords.contains(searchTextField.text!)){
              moreImages.isEnabled=true
              resultImage.image=UIImage(named: array[4][flag])
              topic=5
              topicInfoText.text="A flower, sometimes known as a bloom or blossom, is the reproductive structure found in flowering plants. The biological function of a flower is to facilitate reproduction, usually by providing a mechanism for the union of sperm with eggs. Flowers may facilitate outcrossing  resulting from cross-pollination or allow selfing when self-pollination occurs."
          }
          else {
              resultImage.image = UIImage(named: array[5][flower])
              moreImages.isHidden=true
              topicInfoText.isHidden=true
              searchBtn.isEnabled=false
              searchBtn.alpha=0.5
          }
          
          
      }
      @IBAction func showMoreImagesBtn(_ sender: UIButton) {
          
          if(topic==1){
              animal+=1
              updateData(imgNum: animal)
          }
          if(topic==2){
              
              bird+=1
              updateData(imgNum: bird)
          }
          if(topic==3){
              
              chocolate+=1
              updateData(imgNum: chocolate)
          }
          if(topic==4){
              
              flag+=1
              updateData(imgNum: flag)
          }
          if(topic==5){
              
              flower+=1
              updateData(imgNum: 2)
          }
      }
      
      func updateData(imgNum: Int){
          if(topic==1){
              
              if  animal == array[0].count  {
                moreImages.backgroundColor = .gray
                  moreImages.isEnabled = false
                  
              }else{
                  resultImage.image = UIImage(named: array[0][animal])
                  
              }
          }
          if(topic==2){
              if(bird==array[1].count){
                moreImages.backgroundColor = .black
                  moreImages.isEnabled=false
              }else{
                  resultImage.image=UIImage(named: array[1][bird])
              }
          }
          if(topic==3){
              if(chocolate==array[2].count){
                moreImages.backgroundColor = .brown
                  moreImages.isEnabled=false
              }else{
                  resultImage.image=UIImage(named: array[2][chocolate])
              }
              
          }
          if(topic==4){
              if(flag==array[3].count){
                moreImages.backgroundColor = .darkText
                  moreImages.isEnabled=false
              }else{
                  resultImage.image=UIImage(named: array[3][flag])
              }
          }
          if(topic==5){
              if(flower==array[4].count){
                moreImages.backgroundColor = .magenta
                  moreImages.isEnabled=false
              }else{
                  resultImage.image=UIImage(named: array[4][flower])
              }
          }
          
      }
      
      
      @IBAction func ResetButtonClicked(_ sender: UIButton) {
          topicInfoText.isHidden=true
          moreImages.isHidden=true
          searchBtn.isEnabled=false
          searchBtn.alpha=0.5
          resetButton.isHidden=true
          resultImage.image=UIImage(named: array[5][0])
          searchTextField.text=""
          
      }
      
    @IBAction func searchTextFieldChanged(_ sender: UITextField) {
        searchBtn.isEnabled=true
        if(sender.text==""){
            searchBtn.isEnabled=false
            searchBtn.alpha=0.5
    }
    }
  }
   
