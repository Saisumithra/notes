//
//  ViewController.swift
//  Jagarlamudi_FormatName
//
//  Created by Jagarlamudi,Saisumithra on 9/7/21.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var firstNameTextField: UITextField!
    
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
           
    
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        displayLabel.text = ""
        firstNameTextField.becomeFirstResponder();
    }
    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        displayLabel.text = "\(lastNameTextField.text!), \(firstNameTextField.text!)";
    }
}

