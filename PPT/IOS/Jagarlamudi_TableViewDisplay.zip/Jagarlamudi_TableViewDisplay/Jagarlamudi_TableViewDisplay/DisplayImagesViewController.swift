//
//  DisplayImagesViewController.swift
//  Jagarlamudi_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class DisplayImagesViewController: UIViewController {

    @IBOutlet weak var displayLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    var imageName = ""
    var itemName = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        print(imageName)
        imageView.image = UIImage(named: "\(imageName)")
    }
    
    @IBAction func getInfo(_ sender: Any) {
        
        if itemName == "cars"{
            displayLabel.text = "A car (or automobile) is a wheeled motor vehicle used for transportation. Most definitions of cars say that they run primarily on roads, seat one-to-eight people, have four wheels and mainly transport people rather than goods."
        }
        else if itemName == "flowers"
        {
            displayLabel.text = "A flower, sometimes known as a bloom or blossom, is the reproductive structure found in flowering plants (plants of the division Magnoliophyta, also called angiosperms). "
        }
        else{
            displayLabel.text = "In computational complexity theory, a gadget is a subset of a problem instance that simulates the behavior of one of the fundamental units of a different computational problem."
        }
    }
    
    

}
