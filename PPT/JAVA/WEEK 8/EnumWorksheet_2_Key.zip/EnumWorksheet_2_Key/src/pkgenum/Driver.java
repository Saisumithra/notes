/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgenum;

import java.util.Scanner;

/**
 *
 * @author Instructor
 */
public class Driver {
    
         public static void main(String[] args) {
        // TODO code application logic here
         
         Scanner sc = new Scanner(System.in);
         System.out.println("Enter the direction you want to travel:");
         String enteredDirection = sc.nextLine();
         Direction d = new Direction();
         if(enteredDirection.equals("east")||enteredDirection.equals("East")||enteredDirection.equals("EAST")){
             d.directionToGo(EnumDirections.EAST);
         }
         else if(enteredDirection.equals("west")||enteredDirection.equals("West")||enteredDirection.equals("WEST")){
             d.directionToGo(EnumDirections.WEST);
         }
         else if(enteredDirection.equals("south")||enteredDirection.equals("South")||enteredDirection.equals("SOUTH")){
             d.directionToGo(EnumDirections.SOUTH);
         }
         else{
             d.directionToGo(EnumDirections.NORTH);
         }
         

    }
    
}
