/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgenum;

import java.util.Scanner;

/**
 *
 * @author Instructor
 */


public class Direction{
    public void directionToGo(EnumDirections d){
        if(d == EnumDirections.EAST){
            System.out.println("Go towards East for 30 miles to reach your destination");
        }
        else if(d == EnumDirections.WEST){
            System.out.println("Go towards West for 60 miles to reach your destination");
        }
        else if(d == EnumDirections.SOUTH){
            System.out.println("Go towards South for 100 miles to reach your destination");
        }
        else{
            System.out.println("Go towards North for 3 miles to reach your destination");
        }
    }
}


